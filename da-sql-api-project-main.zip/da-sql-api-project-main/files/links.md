### Pictures and short infos of everything important you should know about the hurricane Ida.

1. Washington Post: [Good to know](https://www.washingtonpost.com/photography/interactive/2021/photos-ida-norteast/?itid=lb_hurricane-ida-what-you-need-to-know_1).
2. Simpleflying: [NYC airport](https://simpleflying.com/new-york-airports-hurricane-ida/#:~:text=To%20Hurricane%20Ida-,New%20York%2DArea%20Airports%20Face%20Flooding%20And,Flights%20Due%20To%20Hurricane%20Ida&text=As%20Hurricane%20Ida%20brings%20thundering,terminal%20sections%20to%20close%20off).
3. New York Times: [Newark halts flights](https://www.nytimes.com/2021/09/02/nyregion/newark-airport-flights-flooding-halted-ida.html).
